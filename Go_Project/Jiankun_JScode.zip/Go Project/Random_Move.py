import random

OutputFile = open('Output.json','w')
OutputFile.write("[")
board = []


for i in range(0,19):
    for j in range(0,19):
        board.append((i,j))


for i in range(0,300):
    i = int(random.random()*19)
    j = int(random.random()*19)


    if (i,j) in board:
        OutputFile.write("{\"x\":%d,\"y\":%d},"%(i,j))
        board.remove((i,j))

OutputFile.write("{\"x\":%d,\"y\":%d}]"%board[20])
