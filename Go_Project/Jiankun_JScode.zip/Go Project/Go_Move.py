import random
from game_state import Position, empty_position, board_state_to_numpy_arr
import numpy

OutputFile = open('Output.json','w')
OutputFile.write("[")

myGame = empty_position()

i = 10
j = 10
# parse i, j to game_state
myGame = myGame.move(i+20*j+21)
OutputFile.write("{\"x\":%d,\"y\":%d},"%(i,j))
#print (type(myGame))

narr = board_state_to_numpy_arr(myGame.board)

#AI thinks and returns a move

# convert narr to json
AI_move = 300
myGame.move(AI_move)
j = int((AI_move - 21)/20)
i = AI_move - 21 - 20 * j
OutputFile.write("{\"x\":%d,\"y\":%d},"%(i,j))


OutputFile.write("{}]")
